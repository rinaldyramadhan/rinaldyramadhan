<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	private $template = "layout/template";

	public function index()
	{
		$data['title']		=		'Login';
		$data['konten']		=		'login';

		$this->M_auth->loginRules();
		if ($this->form_validation->run() == false ) {
			$this->load->view($this->template,$data);
		} else {
			$this->_login();
		}
	}

	private function _login(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->db->get_where('user', ['email'=>$email])->row_array();

		// cek user
		if ($user) {
			
			// usernya aktif
			if ($user['is_active'] == 1) {

				//cek password
				if (password_verify($password, $user['password'])) {
					// berhasil login

					if ($user['level'] == 'Member' ) {

						$data = [
						'email'		=> $user['email'],
						'level'		=> $user['level']
						];

						$this->session->set_userdata($data);
						$this->session->set_flashdata('pesan', '<div class="alert alert-success">
							Berhasil login
						</div>');

						redirect('user/dashboard');
					} elseif ($user['level'] == 'Admin') {

						$data = [
						'email'		=> $user['email'],
						'level'		=> $user['level']
						];

						$this->session->set_userdata($data);
						$this->session->set_flashdata('pesan', '<div class="alert alert-success">
							Berhasil login
						</div>');

						redirect('admin/dashboard');
					}					
				} else {
					// tidak berhasil login
					$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
						Salah password!
					</div>');

					redirect('login');
				}

			} else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
					Email ini belum aktif silahkan aktifkan email!
				</div>');
				redirect('login');
			}

		} else {
			// usernya tidak ada
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
					Email ini tidak terdaftar!
				</div>');
				redirect('login');
		}
	}

	public function pendaftaran()
	{
		$data['lokasi']			=		$this->M_auth->getDataLokasi();
		$data['kategori']		=		$this->M_auth->getDataKategori();

		$data['title']		=		'Pendaftaran';
		$data['konten']		=		'pendaftaran';

		// validasi
		$this->M_auth->pendaftaranRules();
		if ($this->form_validation->run() == false ) {
			$this->load->view($this->template,$data);
		} else {
			$this->M_auth->saveDataPendaftaran();

			redirect('login');
		}
	}


	public function logout()
	{
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('level');

		$this->session->set_flashdata('pesan', '<div class="alert alert-success">
			Berhasil melakukan logout
		</div>');

		redirect('login');
	}





}
