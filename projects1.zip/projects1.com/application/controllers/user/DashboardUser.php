<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardUser extends CI_Controller {

	private $template = 'layout/template';

	public function __construct(){
		parent::__construct();


		if ($this->session->userdata('level') == 'Member') {

		} else {
			redirect('login');
		}
	}


	public function index(){
		$data['user']	=	$this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$data['lokasi']			=		$this->M_auth->getDataLokasi();
		$data['kategori']		=		$this->M_auth->getDataKategori();

		$data['title']	=	'Dashboard';
		$data['konten']	=	'user/dashboard';

		$this->M_dashboard->outletRules();
		if ($this->form_validation->run() == false) {
			$this->load->view($this->template, $data);
		} else {
			$this->M_dashboard->saveOutlet();
		}
	}


}