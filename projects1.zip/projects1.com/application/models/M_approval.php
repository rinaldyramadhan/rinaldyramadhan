<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_approval extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	function getIklan(){
		return $this->db->get('iklan');
	}

	function joinIklan(){
		$this->db->select('*');
		$this->db->from('iklan');
		$this->db->join('user', 'user.id = iklan.id');
		$query = $this->db->get();
		return $query;
	}
	
}