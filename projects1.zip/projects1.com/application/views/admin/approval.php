<header id="header" class="text-center">
	<h5><?php echo $title ?></h5>
</header><!-- /header -->

<div class="card">
	<div class="card-body">
		<table class="table table-sm table-bordered table-hover" id="myTable">
			<thead>
				<tr class="text-center">
					<th>User</th>
					<th>Iklan</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($iklan->result_array() as $a): ?>
				<tr>
					<td><?php echo $a['iduser'] ?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>


