<header id="header" class="text-center">
		<form action="" method="get" accept-charset="utf-8">
				
			<div class="form-group">
				<label for="">Pencarian Kategori</label>
				<div class="row justify-content-center">
					<div class="col-12">
						<select name="pencarian" class="mr-2 mb-3">
							<option value="Featured Franchise">Featured Franchise</option>
							<option value="Popular">Popular</option>
						</select>
						<button type="submit" class="btn btn-sm btn-secondary">Cari</button>
					</div>
					
				</div>
			</div>
		</form>		
</header><!-- /header -->	



<p class="text-index">
		<a href="" title="">Featured Franchise</a> <br>
		Daftar usaha waralaba yang menjadi prioritas utama advertising WaralabaKu.com
</p>

<p class="text-index">
	<small>
		<a href="" title="">Popular Franchise</a> <br>
		Daftar usaha waralaba yang paling banyak dikunjungi oleh pengunjung WaralabaKu.com (hit rate tertinggi)
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Berdasarkan Kategori</a> <br>
		Daftar usaha waralaba berdasarkan kategori dan sub kategori industri atau bidang usaha.
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Berdasarkan Abjad</a> <br>
		Daftar usaha waralaba berdasarkan urutan alfabet dari nama merek dagangnya.
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Advanced Search</a> <br>
		Klik untuk menggunakan fasilitas advanced search kami dalam mencari informasi tentang usaha waralaba yang spesifik.
	</small>		
</p>	


<hr>


