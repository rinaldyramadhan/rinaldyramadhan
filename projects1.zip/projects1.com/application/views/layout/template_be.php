<?php $this->load->view('layout/_partials/head') ?>
  <body>

<?php $this->load->view('layout/_partials/navbar') ?>


    <div class="container">
      <div class="row justify-content-center">
       <div class="col-12">
         <div class="row mt-1">

           <div class="col-3"> <!-- left sidebar -->
            <header id="header" class="text-center">
              <h5 >Menu</h5>
            </header><!-- /header --> 
            <div class="card p-1 bg-light">
              <a href="<?php echo base_url('login') ?>" class="btn btn-sm btn-secondary mt-2 mb-2" title="">Login</a>
              <a href="<?php echo base_url('pendaftaran') ?>" class="btn btn-sm btn-secondary mb-2" title="">Pendaftaraan</a>
            </div>
            <div class="banner-index">
              <img src="<?= base_url('assets/images/banner/banner-right-side-1.gif') ?>" alt="asdas" width="100%">
            </div>
            <div class="banner-index">
              <img src="<?= base_url('assets/images/banner/banner-index-1.gif') ?>" alt="asdas" width="100%">
            </div>
           </div> <!-- col-3  left sidebar -->

            <div class="col-6"> <!-- main content -->
              
              <?php $this->load->view($konten) ?>


              <hr>

              <header id="header" class="text-center">
                <p class="text-header">Featured Franchise</p>
              </header><!-- /header -->

              <div class="row">
                <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-1.jpg') ?>" alt="" width="100%">
                    <div class="container-text">
                      <a href="" title="">Qualitat vending machine</a>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-2.jpg') ?>" alt="" width="100%">
                    <div class="container-text">
                    <a href="" title="">ORCHI Fried Chicken</a>
                  </div>
                  </div>
                </div>

                 <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-3.jpg') ?>" alt="" width="100%">

                  </div>
                </div>
              </div>   <!-- /row featured franchise -->



            </div> <!-- / main content -->

           <div class="col-3"> <!-- col-3 right side -->
             <header id="header" class="text-center">
               <h5 class="ml-2">Promo Waralaba</h5>
             </header><!-- /header -->
             <div class="card">
                <img src="<?= base_url('assets/images/banner/banner-right-side-1.gif') ?>" alt="asdas" width="100%">
             </div> 
           </div>
         </div> 
       </div> 
      </div>  
      
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>