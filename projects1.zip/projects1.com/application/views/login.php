<header id="header" class="text-center">
	<h5>Form-Login</h5>
</header><!-- /header -->

<?php echo $this->session->flashdata('pesan') ?>

<form action="<?php echo base_url('auth') ?>" method="post" accept-charset="utf-8" class="p-3">
	<div class="form-group">
		<label for="email">Email</label>
		<input type="text" name="email" placeholder="Masukan Email" class="form-control">
		<?php echo form_error('email', '<small class="text-danger">','</small>') ?>
	</div>	
	<div class="form-group">
		<label for="password">Password</label>
		<input type="password" name="password" placeholder="Masukan Password" class="form-control">
		<?php echo form_error('password', '<small class="text-danger">','</small>') ?>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">Login</button>
	</div>	
</form>	