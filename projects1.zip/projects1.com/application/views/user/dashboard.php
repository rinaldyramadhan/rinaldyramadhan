<header id="header" class="text-center">
	<h5><?php echo $title ?></h5>
</header><!-- /header -->

<?php echo $this->session->flashdata('pesan') ?>

<div class="card mt-2 mb-2">
	<div class="card-body">

	<?php 
		$data = $this->db->get_where('outlet',['iduser'=>$user['Id']])->row_array();
		// jika data tidak ada maka munculkan form kosong
	if (!$data): ?>
		<form action="<?php echo base_url('user/dashboard') ?>" method="post" accept-charset="utf-8" class="p-3">

			<!-- hidden  -->
			<input type="text" name="iduser" value="<?php echo $user['Id'] ?>" hidden>
			<!-- / hidden  -->
			<div class="form-group">
				<label for="nama_outlet">Nama Outlet <span class="text-danger">*</span></label>
				<input type="text" name="nama_outlet" placeholder="Masukan Outlet" class="form-control" value="<?php echo set_value('nama_outlet') ?>" autofocus>
				<?php echo form_error('nama_outlet', '<small class="text-danger">','</small>') ?>
			</div>

			<div class="form-group">
				<label for="phone_outlet">No. Telp Outlet / WA <span class="text-danger">*</span></label>
				<input type="text" name="phone_outlet" placeholder="Masukan No. Telp Outlet" value="<?php echo set_value('phone_outlet') ?>" class="form-control">
				<?php echo form_error('phone_outlet', '<small class="text-danger">','</small>') ?>
			</div>

			<div class="form-group">
				<label for="idlokasi">Lokasi <span class="text-danger">*</span></label>
				<select name="idlokasi" class="form-control">
					<?php foreach ($lokasi->result_array() as $l): ?>
						<option value="<?php echo $l['Id'] ?>"><?php echo $l['nama_lokasi'] ?></option>
					<?php endforeach ?>
				</select>
			</div>

			<div class="form-group">
				<label for="alamat_outlet">Alamat Outlet</label>
				<textarea name="alamat_outlet" class="form-control" placeholder="Masukan Alamat"><?php echo set_value('alamat_outlet') ?></textarea>
				<?php echo form_error('alamat_outlet', '<small class="text-danger">','</small>') ?>
			</div>		

			<div class="form-group">
				<label for="idkategori">Kategori <span class="text-danger">*</span></label>
				<select name="idkategori" class="form-control">
					<?php foreach ($kategori->result_array() as $l): ?>
						<option value="<?php echo $l['Id'] ?>"><?php echo $l['nama_kategori'] ?></option>
					<?php endforeach ?>
				</select>
			</div>	
			
			<div class="form-group">
				<button type="submit" class="btn btn-success">Simpan</button>
			</div>	
		</form>	
	<?php // jika data ada maka data sudah tersimpan
	else: ?>
		<div class="text-center">
			<p>Data Outlite berhasil tersimpan</p>	
		</div>
	<?php endif ?>

	</div> <!-- / cardbody -->
	
	
</div>


