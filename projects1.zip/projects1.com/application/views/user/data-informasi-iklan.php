<header id="header" class="text-center">
	<h5><?php echo $title ?></h5>
</header><!-- /header -->

			<div class="text-center" >
			Masukan Data Profil Outlet Kamu	
			</div>
			<br>

		<?php echo form_open_multipart('user/PasangIklan/upload_data');?>

			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 1</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan1" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 1</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar1"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 2</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan2" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 2</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar2"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 3</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan3" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 3</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar3"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 4</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan4" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 4</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar4"></textarea>
				</div>	
			</div>


				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 5</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan5" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 5</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar5"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 6</label>
				</div>
				<div class="col-8"
				<input type="file" name="desk_iklan6" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 6</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar6"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 7</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan7" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 7</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar7"></textarea>
				</div>	
			</div>

			
				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 8</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan8" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 8</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar8"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 9</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan9" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 9</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar9"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 10</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan10" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 10</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar10"></textarea>
				</div>	
			</div>

		<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 11</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan11" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 11</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar11"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 12</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan12" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 12</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar12"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 13</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan13" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 13</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar13"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 14</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan14" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 14</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar14"></textarea>
				</div>	
			</div>


				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 15</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan15" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 15</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar15"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 16</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan16" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 16</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar16"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 17</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan17" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 17</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar17"></textarea>
				</div>	
			</div>

			
				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 18</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan18" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 18</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar18"></textarea>
				</div>	
			</div>

						<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 19</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan19" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 19</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar19"></textarea>
				</div>	
			</div>

				<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Gambar Iklan 20</label>
				</div>
				<div class="col-8">
				<input type="file" name="desk_iklan20" class="form-control-file">	
				</div>	
			</div>
			<div class="form-group row">
				<div class="col-4">
				<label for="desk_iklan"> Deskripsi Iklan 20</label>
				</div>
				<div class="col-8">
					<textarea class="form-control" name="deskripsigambar20"></textarea>
				</div>	
			</div>

			<div class="text-center" >
				<button type="submit" class="btn btn-primary form-control" >Pasang</button>
			</div>

	</form>