-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2020 at 06:24 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waralaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `Id` int(6) NOT NULL,
  `iduser` int(6) NOT NULL,
  `nama_artikel` varchar(128) NOT NULL,
  `link_artikel` varchar(255) NOT NULL,
  `author` varchar(150) NOT NULL,
  `afiliasi` varchar(150) NOT NULL,
  `tanggal` date NOT NULL,
  `topik` varchar(150) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gambar_iklan`
--

CREATE TABLE `gambar_iklan` (
  `Id` int(6) NOT NULL,
  `idiklan` int(6) NOT NULL,
  `nama_gambar` varchar(250) NOT NULL,
  `deskripsigambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gambar_iklan`
--

INSERT INTO `gambar_iklan` (`Id`, `idiklan`, `nama_gambar`, `deskripsigambar`) VALUES
(1, 0, 'logo-1.jpg', ''),
(2, 0, 'logo-2.jpg', ''),
(3, 0, 'logo-11.jpg', ''),
(4, 0, 'logo-21.jpg', ''),
(5, 0, 'logo-12.jpg', ''),
(6, 0, 'logo-22.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `iklan`
--

CREATE TABLE `iklan` (
  `Id` int(6) NOT NULL,
  `iduser` int(11) NOT NULL,
  `nama_iklan` varchar(250) NOT NULL,
  `deskripsi` text NOT NULL,
  `idkategori` int(6) NOT NULL,
  `nama_usaha` varchar(250) NOT NULL,
  `sejak` date NOT NULL,
  `jumlah_gerai` int(11) NOT NULL,
  `modal` int(11) NOT NULL,
  `fee` double NOT NULL,
  `royalty` double NOT NULL,
  `advertising` double NOT NULL,
  `gambar` varchar(250) NOT NULL,
  `status_approval` tinyint(1) NOT NULL DEFAULT 0,
  `tgl_mulai` date DEFAULT NULL,
  `tgl_berakhir` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iklan`
--

INSERT INTO `iklan` (`Id`, `iduser`, `nama_iklan`, `deskripsi`, `idkategori`, `nama_usaha`, `sejak`, `jumlah_gerai`, `modal`, `fee`, `royalty`, `advertising`, `gambar`, `status_approval`, `tgl_mulai`, `tgl_berakhir`) VALUES
(1, 2, 'bobaz', 'asgasg', 0, 'sfasdf', '2019-12-31', 123, 512521, 12312, 12412, 12412, 'logo-24.jpg', 0, '0000-00-00', '0000-00-00'),
(2, 2, '', '', 0, '', '0000-00-00', 0, 0, 0, 0, 0, 'logo-23.jpg', 0, NULL, NULL),
(3, 2, '', 'asdfasg', 0, 'asfdaf', '2019-12-31', 123214, 123124, 124124, 12421, 12421, 'logo-127.jpg', 0, NULL, NULL),
(4, 2, 'Boba', 'Bobaaaa', 0, 'Boba LIKE', '2019-12-31', 123, 112, 0, 0, 0, 'logo-24.jpg', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `Id` int(6) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`Id`, `nama_kategori`) VALUES
(1, 'Otomotif'),
(2, 'Bussines Services'),
(3, 'Furniture,Konstruksi,Properti'),
(4, 'Jasa Pendidikan & Pelatihan'),
(5, 'Hiburan & Hobi'),
(6, 'Penginapan & Travel'),
(7, 'KomputerInternet,& Teknologi'),
(8, 'Makanan & Minuman'),
(9, 'Laundry & Jasa Kebersihan'),
(10, 'kesehatan & kecantikan'),
(11, 'Anak & Balita'),
(12, 'Lainya');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `Id` int(6) NOT NULL,
  `nama_lokasi` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`Id`, `nama_lokasi`) VALUES
(1, 'DKI Jakarta'),
(2, 'Jawa Barat'),
(3, 'Jawa Tengah'),
(4, 'Jawa Timur'),
(5, 'Jogjakarta'),
(6, 'Bali'),
(7, 'Banten'),
(8, 'Bengkulu'),
(9, 'Gorontalo'),
(10, 'Jambi'),
(11, 'Kalimantan Barat'),
(12, 'Kalimantan Selatan'),
(13, 'Kalimantan Tengah'),
(14, 'Kalimantan Timur'),
(15, 'Kepulauan Bangka Belitung'),
(16, 'Kepulauan Riau'),
(17, 'Lampung'),
(18, 'Maluku'),
(19, 'Maluku Utara'),
(20, 'Aceh'),
(21, 'Nusa Tenggara Barat'),
(22, 'Nusa Tenggara Timur'),
(23, 'Papua'),
(24, 'Papua Barat'),
(25, 'Riau'),
(26, 'Sulawesi Barat'),
(27, 'Sulawesi Selatan'),
(28, 'Sulawesi Tengah'),
(29, 'Sulawesi Tenggara'),
(30, 'Sulawesi Utara'),
(31, 'Sumatra Barat'),
(32, 'Sumatra Selatan'),
(33, 'Sumatra Utara');

-- --------------------------------------------------------

--
-- Table structure for table `outlet`
--

CREATE TABLE `outlet` (
  `Id` int(6) NOT NULL,
  `iduser` int(6) NOT NULL,
  `nama_outlet` varchar(128) NOT NULL,
  `idkategori` int(6) NOT NULL,
  `idlokasi` int(6) NOT NULL,
  `alamat_outlet` text NOT NULL,
  `phone_outlet` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outlet`
--

INSERT INTO `outlet` (`Id`, `iduser`, `nama_outlet`, `idkategori`, `idlokasi`, `alamat_outlet`, `phone_outlet`) VALUES
(1, 2, 'Flash.Net', 7, 1, 'Jakarta Selatan, Tebet Dalam Gang F', '088213999180');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(6) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `level` varchar(150) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `date_created` date NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `nama`, `alamat`, `level`, `phone`, `email`, `password`, `date_created`, `is_active`) VALUES
(2, 'Rinaldy Ramadhan', 'Bekasi', 'Member', '088213989180', 'rinaldy.haha@gmail.com', '$2y$10$ivHmwJPuQsR1ZAF75.f7m.g8R4nNBJcDYvyE2SAhF6dWZTEwsUVfy', '2020-03-17', 1),
(3, 'Admin', 'Jl. Amin No. 3', 'Admin', '088213989189', 'admin@admin.com', '$2y$10$pGmLUPmb928CxqF2yIsLD.HauJRiF6z7b4ZRiFklFCiVjUF1Kmcnm', '2020-03-17', 1),
(4, 'Alfian', 'Bekasi', 'Member', '088213989180', 'alfian@gmail.com', '$2y$10$MziqIwhiffHMDnIa7nIvY.0LqURfJ/a..t5S8rcCSL7gKdTlnaTuS', '2020-03-17', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `gambar_iklan`
--
ALTER TABLE `gambar_iklan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `iklan`
--
ALTER TABLE `iklan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `outlet`
--
ALTER TABLE `outlet`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gambar_iklan`
--
ALTER TABLE `gambar_iklan`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `iklan`
--
ALTER TABLE `iklan`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `outlet`
--
ALTER TABLE `outlet`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
