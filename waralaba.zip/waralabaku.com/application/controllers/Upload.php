<?php 
class Upload extends CI_Controller{
 
	function __construct(){
		parent::__construct();
		  $this->load->helper(array('form', 'url'));
	}
 
	public function index(){
		$this->load->view('v_upload', array('error' => ' ' ));
	}
 
	public function aksi_upload_iklan(){
		$config['upload_path']          = './assets/images/gambar_pasangiklan/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
 
		$this->load->library('upload', $config);
 
		if ( ! $this->upload->do_upload('berkas')){

			$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
			Gagal mengupload foto! silahkan cek file upload!
		</div>');

		redirect('user/dashboard');

			/*$error = array('error' => $this->upload->display_errors());
			$this->load->view('v_upload', $error);*/
		}else{
			/*$data = array('upload_data' => $this->upload->data());*/

			$upload_foto	=	$this->upload->data('');

			$dataPasang = [
				'iduser'	=> $this->input->post('iduser'),
				'deskripsi'	=> $this->input->post('deskripsi'),
				'nama_usaha'	=> $this->input->post('nama_usaha'),
				'sejak'	=> $this->input->post('sejak'),
				'jumlah_gerai'	=> $this->input->post('jumlah_gerai'),
				'modal'	=> $this->input->post('modal'),
				'fee'	=> $this->input->post('fee'),
				'royalty'	=> $this->input->post('royalty'),
				'advertising'	=> $this->input->post('advertising'),
				'status_approval'	=> 0,
				'gambar'	=> $upload_foto['file_name']		
			];

				$this->session->set_flashdata('pesan','<div class="alert alert-success">
					Berhasil, silahkan konfimasikan pada admin
				</div>');

			$this->db->insert('iklan', $dataPasang);

			redirect('user/dashboard');

		}
	}
	
}

?>