<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Approval extends CI_Controller {

	private $template = 'layout/template';

	public function __construct(){
		parent::__construct();
		if ($this->session->userdata('level') == 'Admin') {

		} else {
			redirect('login');
		}
	}


	public function index(){
		$data['user']	=	$this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$data['title']	=	'Approval Status';
		$data['konten']	=	'admin/approval';
		$data['iklan']	=	$this->M_approval->joinIklan();

		$this->load->view($this->template,$data);
	}


}