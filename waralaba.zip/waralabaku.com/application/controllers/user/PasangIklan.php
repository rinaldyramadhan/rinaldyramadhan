<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PasangIklan extends CI_Controller {

	private $template = 'layout/template';

	public function __construct(){
		parent::__construct();
		if ($this->session->userdata('level') == 'Member') {

		} else {
			redirect('login');
		}
	}

	public function index(){
		$data['user']	=	$this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$user = $this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$data['lokasi']			=		$this->M_auth->getDataLokasi();
		$data['kategori']		=		$this->M_auth->getDataKategori();
		$data['iklan']		=		$this->db->get_where('iklan', ['iduser'=>$user['Id']])->row_array();

		$data['title']	=	'Pasang Iklan';
		$data['konten']	=	'user/pasang-iklan';

		$this->M_PasangIklan->iklanRules();
		if ($this->form_validation->run() == false) {
			$this->load->view($this->template, $data);
		} else {
			$this->aksi_upload_iklan();
		}
	}

	public function aksi_upload_iklan(){
		$config['upload_path']          = './assets/images/gambar_pasangiklan/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
 
		$this->load->library('upload', $config);
 
		if ( ! $this->upload->do_upload('berkas')){

			$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
			Gagal mengupload file silahkan cek file upload!
		</div>');

		redirect('user/dashboard');

			/*$error = array('error' => $this->upload->display_errors());
			$this->load->view('v_upload', $error);*/
		}else{
			/*$data = array('upload_data' => $this->upload->data());*/

			$upload_foto	=	$this->upload->data('');

			$dataPasang = [
				'iduser'	=> $this->input->post('iduser'),
				'nama_iklan'	=> $this->input->post('nama_iklan'),
				'deskripsi'	=> $this->input->post('deskripsi'),
				'nama_usaha'	=> $this->input->post('nama_usaha'),
				'sejak'	=> $this->input->post('sejak'),
				'jumlah_gerai'	=> $this->input->post('jumlah_gerai'),
				'modal'	=> $this->input->post('modal'),
				'fee'	=> $this->input->post('fee'),
				'royalty'	=> $this->input->post('royalty'),
				'advertising'	=> $this->input->post('advertising'),
				'status_approval'	=> 0,
				'gambar'	=> $upload_foto['file_name']		
			];

				$this->session->set_flashdata('pesan','<div class="alert alert-success">
					Berhasil, silahkan konfimasikan pada admin
				</div>');

			$this->db->insert('iklan', $dataPasang);

			redirect('user/dashboard');

		}
	}


	public function data_informasi_iklan(){
		$data['user']	=	$this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$user = $this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
		$data['lokasi']			=		$this->M_auth->getDataLokasi();
		$data['kategori']		=		$this->M_auth->getDataKategori();
		$data['iklan']		=		$this->db->get_where('iklan', ['iduser'=>$user['Id']])->row_array();

		$data['title']	=	'Data Profil Franchise';
		$data['konten']	=	'user/data-informasi-iklan';

		$this->M_PasangIklan->iklanRules();
		if ($this->form_validation->run() == false) {
			$this->load->view($this->template, $data);
		} else {
			$this->aksi_upload_iklan();
		}
	}


	public function upload_data(){
		$config['upload_path']          = './assets/images/gambar_dataiklan/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 0;
		/*$config['max_width']            = 1024;
		$config['max_height']           = 768;*/
 
		$this->load->library('upload', $config);

		for ($i=1; $i < 20 ; $i++) { 
 
			if ( ! $this->upload->do_upload('desk_iklan'.$i++)){

				$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
				Gagal mengupload file silahkan cek file upload!
			</div>');

			redirect('user/dashboard');

				/*$error = array('error' => $this->upload->display_errors());
				$this->load->view('v_upload', $error);*/
			}else{
				/*$data = array('upload_data' => $this->upload->data());*/

				$upload_foto	=	$this->upload->data('');

				$dataPasang = [		
					'nama_gambar'	=> $upload_foto['file_name'],
					'deskripsigambar' => $this->input->post('deskripsigambar'.$i++)	
				];

					$this->session->set_flashdata('pesan','<div class="alert alert-success">
						Berhasil, silahkan konfimasikan pada admin
					</div>');

				$this->db->insert('gambar_iklan', $dataPasang);

				redirect('user/dashboard');
			}
		}

	}

}