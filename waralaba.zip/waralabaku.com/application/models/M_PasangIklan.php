<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_PasangIklan extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	public function iklanRules(){

		$this->form_validation->set_rules('nama_iklan', 'Nama Iklan', 'required|trim',[
				'required'		=>		'Nama Iklan harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('deskripsi', 'Deskripsi Iklan', 'required|trim',[
				'required'		=>		'Deskripsi iklan / outlet harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('nama_usaha', 'Nama Perusahaan', 'required|trim',[
				'required'		=>		'Nama Perusahaan harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('sejak', 'Berdiri Sejak', 'required|trim',[
				'required'		=>		'Tanggal Berdirinya Usaha harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('jumlah_gerai', 'Jumlah Gerai', 'required|trim|numeric',[
				'required'		=>		'Jumlah Gerai harus di isi tidak boleh kosong!',
				'numeric'		=>		'Hanya diperbolehkan angka / numerik '
		]);

		$this->form_validation->set_rules('modal', 'Modal Awal', 'required|trim|numeric',[
				'required'		=>		'Modal Awal harus di isi tidak boleh kosong!',
				'numeric'		=>		'Hanya diperbolehkan angka / numerik '
		]);

		$this->form_validation->set_rules('fee', 'Fee', 'trim|numeric',[
				'numeric'		=>		'Outlet Fee Hanya diperbolehkan angka / numerik '
		]);

		$this->form_validation->set_rules('royalty', 'Biaya Royalti', 'trim|numeric',[
				'numeric'		=>		'Biaya Royalti Hanya diperbolehkan angka / numerik '
		]);

		$this->form_validation->set_rules('advertising', 'Biaya Advertising', 'trim|numeric',[
				'numeric'		=>		'Biaya Advertising Hanya diperbolehkan angka / numerik '
		]);

		/*$this->form_validation->set_rules('gambar', 'Gambar', 'required|trim',[
				'required'		=>		'Gambar harus di masukan tidak boleh kosong!'
		]);*/
	}

	function saveIklan(){
		

			/* data untuk diupdate pada tabe konfirmasi */
			$dataPasang = [
				'iduser'	=> $this->input->post('iduser'),
				'deskripsi'	=> $this->input->post('deskripsi'),
				'nama_usaha'	=> $this->input->post('nama_usaha'),
				'sejak'	=> $this->input->post('sejak'),
				'jumlah_gerai'	=> $this->input->post('jumlah_gerai'),
				'modal'	=> $this->input->post('modal'),
				'fee'	=> $this->input->post('fee'),
				'royalty'	=> $this->input->post('royalty'),
				'advertising'	=> $this->input->post('advertising'),
				'status_approval'	=> 0			
			];

				$this->session->set_flashdata('pesan','<div class="alert alert-success">
					Berhasil Melakukan Konfirmasi Pembayaran
				</div>');

			$this->db->insert('iklan', $dataPasang);

			redirect('user/dashboard');

	}


	function upload_gambar(){
		$config['upload_path'] = './assets/images/gambar_iklan';
		$config['allowed_types'] = 'gif|png|jpg|pdf';
		$config['max_size'] = 0;
		//$config['max_size']             = 1024; // 1MB
	    // $config['max_width']            = 1024;
	    // $config['max_height']           = 768;
		$this->load->library('upload',$config);
		$this->upload->initialize($config);

		if (! $this->upload->do_upload('gambar')) {
												
		$this->session->set_flashdata('pesan', '<div class="alert alert-danger">
			Gagal mengupload foto! silahkan cek file upload!
		</div>');

		redirect('user/dashboard');

		}	else {
			$upload_foto	=	$this->upload->data('');


			/* data untuk diupdate pada tabe konfirmasi */
			$data = [
				'gambar'	=> $upload_foto['file_name']

			];

			$this->db->insert('iklan', $data);

			redirect('user/dashboard');

		}
	}

	public function aksi_upload(){
		$config['upload_path']          = './assets/images/gambar_pasangiklan/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
 
		$this->load->library('upload', $config);
 
		if ( ! $this->upload->do_upload('berkas')){
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('v_upload', $error);
		}else{
			$data = array('upload_data' => $this->upload->data());
			$this->load->view('v_upload_sukses', $data);
		}
	}
}
