<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_auth extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	function pendaftaranRules(){
		/*|is_unique[user.email]*/
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email',[
				'required'		=>		'Email harus di isi tidak boleh kosong!',
				'valid_email'		=>		'Email tidak valid, pastikan email valid!'
		]);
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[5]|matches[password2]',[
				'required'		=>		'Password harus di isi tidak boleh kosong!',
				'min_length'	=>		'Password terlalu pendek',
				'matches'		=>		'Password password tidak cocok dengan "Konfirmasi Password"'
		]);

		$this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password]',[
				'required'		=>		'Konfirmasi Password harus di isi tidak boleh kosong!',
				'matches'		=>		'Konfirmasi Password tidak cocok dengan "Password"'
		]);

		$this->form_validation->set_rules('nama', 'Nama', 'required|trim|min_length[3]',[
				'required'		=>		'Nama harus di isi tidak boleh kosong!',
				'min_length'	=>		'Nama terlalu pendek'
		]);

		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim',[
				'required'		=>		'Alamat harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('phone', 'Telpon', 'required|trim',[
				'required'		=>		'No Telpon harus di isi tidak boleh kosong!'
		]);


	}


	function saveDataPendaftaran(){
		date_default_timezone_set('Asia/Jakarta');
		$data = [
				'email'			=>		htmlspecialchars($this->input->post('email')),
				'password'		=>		password_hash($this->input->post('password'), PASSWORD_DEFAULT),
				'level'			=>		'Member',
				'nama'			=>		$this->input->post('nama'),
				'alamat'		=>		$this->input->post('alamat'),
				'phone'			=>		$this->input->post('phone'),
				'is_active'		=> 		1,
				'date_created'	=>		date('Y-m-d')
		];

		$this->db->insert('user', $data); // masukan data ke database tabel user
		

		$this->session->set_flashdata('pesan','<div	class="alert alert-success">
				Berhasil melakukan pendaftaran
			</div>');
	}

	function saveDataOutlet(){
		$dataOutlet = [
			'iduser'			=>		$this->input->post('iduser'),
			'nama_outlet'		=>		$this->input->post('nama_outlet'),
			'idkategori'		=>		$this->input->post('idkategori'),
			'idlokasi'			=>		$this->input->post('idlokasi'),
			'alamat_outlet'		=>		$this->input->post('alamat_outlet'),
			'phone_outlet'		=>		$this->input->post('phone_outlet')
		];

		$this->db->insert('outlet', $dataOutlet); // masukan data ke database tabel user

		$this->session->set_flashdata('pesan','<div	class="alert alert-success">
				Berhasil mengisi data outlet
			</div>');
	}


	function loginRules(){
		/*|is_unique[user.email]*/
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email',[
				'required'		=>		'Email harus di isi tidak boleh kosong!',
				'valid_email'		=>		'Email tidak valid, pastikan email valid!'
		]);
		$this->form_validation->set_rules('password', 'Password', 'required|trim',[
				'required'		=>		'Password harus di isi tidak boleh kosong!'
		]);
	}


	function getDataLokasi(){
		$this->db->order_by('Id', 'ASC');
		return $this->db->get('lokasi');
	}

	function getDataKategori(){
		$this->db->order_by('Id', 'ASC');
		return $this->db->get('kategori');
	}



	
}