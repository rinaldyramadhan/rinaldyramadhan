<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dashboard extends CI_Model {

	public function __construct(){
		parent::__construct();
	}

	public function outletRules(){

		$this->form_validation->set_rules('nama_outlet', 'Nama', 'required|trim',[
				'required'		=>		'Nama Outlet harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('alamat_outlet', 'Alamat', 'required|trim',[
				'required'		=>		'Alamat Outlet harus di isi tidak boleh kosong!'
		]);

		$this->form_validation->set_rules('phone_outlet', 'No Telp', 'required|trim|numeric|max_length[15]|min_length[12]',[
				'required'		=>		'No. Telpon harus di isi tidak boleh kosong!',
				'numeric'		=>		'No. Telpon harus di isi dengan angka saja!',
				'min_length'	=>		'Nomor Telpon terlalu pendek [12]',
				'max_length'	=>		'Nomor Telpon terlalu panjang [15]'
		]);
	}

	public function saveOutlet(){
		$dataOutlet = [
			'iduser'	=>	$this->input->post('iduser'),
			'nama_outlet'	=>	$this->input->post('nama_outlet'),
			'idkategori'	=>	$this->input->post('idkategori'),
			'idlokasi'	=>	$this->input->post('idlokasi'),
			'alamat_outlet'	=>	$this->input->post('alamat_outlet'),
			'phone_outlet'	=>	$this->input->post('phone_outlet')
		];

		$this->db->insert('outlet', $dataOutlet);

		$this->session->set_flashdata('pesan', '<div class="alert alert-success">
			Berhasil Menyimpan Data Outlet!
		</div>');

		redirect('user/dashboard');
	}
}