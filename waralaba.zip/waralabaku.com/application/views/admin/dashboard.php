<header id="header" class="text-center">
	<h5><?php echo $title ?></h5>
</header><!-- /header -->

<div class="card">
	<div class="card-body">
		<h5 class="text-center">Data</h5>
		<hr>
	</div>
</div>	