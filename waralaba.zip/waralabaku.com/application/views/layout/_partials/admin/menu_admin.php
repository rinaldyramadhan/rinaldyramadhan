 <header id="header" class="text-center">
  <h5>Menu</h5>
</header><!-- /header --> 
<div class="sidenav">
  <a href="#" title="" class="text-dark">Dashboard</a>
  <button class="dd-btn-user">Manage User
    <i>&#11206;</i>
  </button>
  <div class="dd-container" >
    <a href="#" title="">Page 1</a>
    <a href="#" title="">Page 2</a>
    <a href="#" title="">Page 3</a>
  </div>  
  <button class="dd-btn-iklan">Manage Iklan
    <i>&#11206;</i>
  </button>
   <div class="dd-container">
    <a href="<?php echo base_url('admin/approval-status') ?>" title="">Approval Status</a>
  </div>
  <a href="<?php echo base_url('logout') ?>" title="" class="text-dark mt-2 ">Logout</a>  
</div>