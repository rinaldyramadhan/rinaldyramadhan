 <header id="header" class="text-center">
                <h5>Menu</h5>
</header><!-- /header --> 
<div class="sidenav">
	<a href="<?php echo base_url('user/dashboard') ?>" title="" class="text-dark">Dashboard</a>
	<a href="<?php echo base_url('user/pasang-iklan') ?>" title="" class="text-dark">Pasang Iklan</a>
	<a href="<?php echo base_url('logout') ?>" title="" class="text-dark mt-2">Logout</a>
</div>