<nav>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12">
            <img src="<?= base_url('assets/images/banner/banner-wr-1.jpg') ?>" alt="asdas" width="100%">
            <ul class="menu">
              <li><a href="<?php echo base_url() ?>" title="">Waralaba.com</a></li>
              <li><a href="<?php echo base_url('direktori-waralaba') ?>" title="">Direktori Waralaba</a></li>
              <li><a href="" title="">Pasang iklan </a></li>
              <li><a href="" title="">Hubungi Kami</a></li>
            </ul>
            <div class="banner-index">
              <img src="<?= base_url('assets/images/banner/banner-popup-1.gif') ?>" alt="asdas" width="100%">
            </div>

            <div class="banner-index">
              <img src="<?= base_url('assets/images/banner/banner-popup-2.gif') ?>" alt="asdas" width="100%">
            </div>

          </div>
        </div>  
      </div>
    </nav>