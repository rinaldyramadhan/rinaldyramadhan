<div class="col-3"> 
     <header id="header" class="text-center">
       <h5 class="ml-2">Promo Waralaba</h5>
     </header><!-- /header -->
     <div class="card">
        <img src="<?= base_url('assets/images/banner/banner-right-side-1.gif') ?>" alt="asdas" width="100%">
     </div> 
</div>