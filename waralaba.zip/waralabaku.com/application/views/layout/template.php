
<?php $this->load->view('layout/_partials/head') ?>
  <body>

<?php $this->load->view('layout/_partials/navbar') ?>


    <div class="container">
      <div class="row justify-content-center">
       <div class="col-12">
         <div class="row mt-1">


           <div class="col-3"> <!-- left sidebar / menu -->
            <?php if ($this->session->userdata('level') == 'Member'): ?>
              <!-- left bar / menu member -->
              <?php $this->load->view('layout/_partials/member/menu_member') ?> 

            <?php elseif ($this->session->userdata('level') == 'Admin'): ?>
              <!-- leftside bar / menu admin -->
              <?php $this->load->view('layout/_partials/admin/menu_admin') ?> 
            <?php else: ?>

              <!-- menu pengunjung -->
              <header id="header" class="text-center">
                <h5 >Login & Pendaftaran</h5>
              </header> 
              <div class="card p-1 bg-light">
                <a href="<?php echo base_url('login') ?>" class="btn btn-sm btn-secondary mt-2 mb-2" title="">Login</a>
                <a href="<?php echo base_url('pendaftaran') ?>" class="btn btn-sm btn-secondary mb-2" title="">Pendaftaraan</a>
              </div>
              <div class="banner-index">
                <img src="<?= base_url('assets/images/banner/banner-right-side-1.gif') ?>" alt="asdas" width="100%">
              </div>
              <div class="banner-index">
                <img src="<?= base_url('assets/images/banner/banner-index-1.gif') ?>" alt="asdas" width="100%">
              </div>
            <?php endif; ?>
           </div> <!-- col-3  left sidebar -->


            <?php if ($this->session->userdata('level') == 'Admin'): ?>
            <!-- jika admin maka colom full ke kanan -->
              <div class="col-9"> <!-- main content -->
            <?php else: ?>
              <!-- jika user maka colom main tetap ditengah  -->
              <div class="col-6"> <!-- main content -->
            <?php endif ?>
              
              <?php $this->load->view($konten) ?>
              <hr>

              <header id="header" class="text-center">
                <p class="text-header">Featured Franchise</p>
              </header><!-- /header -->

              <div class="row">
                <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-1.jpg') ?>" alt="" width="100%">
                    <div class="container-text">
                      <a href="" title="">Qualitat vending machine</a>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-2.jpg') ?>" alt="" width="100%">
                    <div class="container-text">
                    <a href="" title="">ORCHI Fried Chicken</a>
                  </div>
                  </div>
                </div>

                 <div class="col-md-6 col-4 col-xl-4 col-sm-6 mb-3">
                  <div class="franchise">
                    <img src="<?= base_url('assets/images/uploads/logo-3.jpg') ?>" alt="" width="100%">

                  </div>
                </div>
              </div>   <!-- /row featured franchise -->



            </div> <!-- / main content -->

            <!-- col-3 right side -->
            <?php if ($this->session->userdata('level') == 'Admin'): ?>
              <!-- jika yang login admin tidak ada rightside bar -->
              
            <?php else: ?>
              <!-- jika member / pengunjung makan munculkan rightside -->
            <?php $this->load->view('layout/_partials/rightsidebar') ?>
            <?php endif ?>


         </div> 
       </div> 
      </div>  
      
    </div>


    <!-- Optional JavaScript -->
    <?php $this->load->view('layout/_partials/js') ?>

  </body>
</html>