<header id="header" class="text-center">
	<h5>Pendaftaran</h5>
</header><!-- /header -->

<form action="<?php echo base_url('auth/pendaftaran') ?>" method="post" accept-charset="utf-8" class="form-pendaftaran">

	<!-- INFORMASI LOGIN -->
	<div class="header">
		<label>Informasi Login</label>
	</div>

	<div class="form-group">
		<label for="email">Email <span class="text-danger">*</span></label>
		<input type="text" name="email" placeholder="Masukan Email" class="form-control" value="<?php echo set_value('email') ?>">
		<small  class="text-danger"><?php echo form_error('email') ?></small>
	</div>

	<div class="form-group">
		<label for="password">Password <span class="text-danger">*</span></label>
		<input type="password" name="password" placeholder="Masukan Password" class="form-control">
		<small  class="text-danger"><?php echo form_error('password') ?></small>
	</div>

	<div class="form-group">
		<label for="password2">Konfirmasi Password <span class="text-danger">*</span></label>
		<input type="password" name="password2" placeholder="Masukan Konfirmasi Password" class="form-control">
		<small  class="text-danger"><?php echo form_error('password2') ?></small>
	</div>
	<!-- / INFORMASI LOGIN -->

	<!-- INFORMASI Data Diri -->
	<div class="header">
		<label>Informasi Data Diri</label>
	</div>

	<div class="form-group">
		<label for="nama">Nama <span class="text-danger">*</span></label>
		<input type="text" name="nama" placeholder="Masukan nama" value="<?php echo set_value('nama') ?>" class="form-control">
		<small  class="text-danger"><?php echo form_error('nama') ?></small>

	</div>

	<div class="form-group">
		<label for="alamat">Alamat <span class="text-danger">*</span></label>
		<textarea name="alamat" class="form-control" rows="4" placeholder="Masukan alamat"><?php echo set_value('alamat') ?></textarea>
		<small  class="text-danger"><?php echo form_error('alamat') ?></small>
	</div>

	<div class="form-group">
		<label for="phone">No Telp / WA <span class="text-danger">*</span></label>
		<input type="text" name="phone" placeholder="Masukan nomor telpon" class="form-control" value="<?php echo set_value('phone') ?>">
		<small  class="text-danger"><?php echo form_error('phone') ?></small>
	</div>



	<div class="form-group">
		<button type="submit" class="btn btn-success">Daftar</button>
	</div>	
</form>	