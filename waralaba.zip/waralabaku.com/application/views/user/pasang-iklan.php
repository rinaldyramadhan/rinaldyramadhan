<header id="header" class="text-center">
	<h5><?php echo $title ?></h5>
</header><!-- /header -->

<div class="card">
	<div class="container-fluid">

	<?php if ($iklan): ?>
		<div class="row justify-content-center">
			<form action="<?php echo base_url('user/PasangIklan/data_informasi_iklan') ?>" method="get" accept-charset="utf-8" class="mt-3 mb-3">
					<button type="submit" class="btn-secondary">Masukan Data Profil Outlet Anda</button>
			</form>
		</div>
		<div class="row p-2 profil-iklan">

				
				
				<div class="col-4">
					<div class="bg-primary p-1">
					<small for=""><strong>Nama Iklan</strong><br>
					<?php echo $iklan['nama_iklan'] ?>
					</small> <br> <br>

					<small for=""><strong>Nama Perusahaan</strong><br>
					<?php echo $iklan['nama_usaha'] ?>
					</small> <br> <br>

					<small for=""><strong>Berdiri Sejak </strong><br>
					<?php echo $iklan['sejak'] ?>
					</small> <br> <br>


					<small for=""><strong>Jumlah Gerai </strong><br>
					<?php echo $iklan['jumlah_gerai'] ?>
					</small> <br> <br>
					</div>
					
				</div>
				<div class="col-4 " align="left">
					<img src="<?php echo base_url('assets/images/gambar_pasangiklan/'. $iklan['gambar']) ?>" width="100%" height="125" alt="gambar" class="mt-3">
				</div>
				<div class="col-4">
					<div class="bg-success p-1">

						<small for=""><strong>Modal Awal</strong><br>
						Rp. <?php echo number_format($iklan['modal'],0,',','.') ?>
						</small> <br> <br>

						<small for=""><strong>Oulet Fee</strong><br>
						Rp. <?php echo number_format($iklan['fee'],0,',','.') ?>
						</small> <br> <br>

						<small for=""><strong>Biaya Advertising </strong><br>
						Rp. <?php echo number_format($iklan['advertising'],0,',','.') ?>
						</small> <br> <br>

						<small for=""><strong></strong><br>
						<!-- Rp. <?php echo number_format($iklan['advertising'],0,',','.') ?> -->
						</small> <br> <br>

					</div>
				</div>
			</div>
	<?php else: ?>
		<?php echo form_open_multipart('user/pasang-iklan');?>

			<!-- <form action="<?php echo base_url('user/pasang-iklan') ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data"> -->
				<!-- hidden -->
			<input type="text" name="iduser" value="<?php echo $user['Id'] ?>" hidden>
			<div class="form-group row">
				<div class="col-4">
					<label for="nama_iklan">Nama Iklan <span class="text-danger">*</span></label>
				</div>
				<div class="col-8">
					<input type="text" name="nama_iklan" class="form-control" value="<?php echo set_value('nama_iklan') ?>">			
				</div>
				<?php echo form_error('nama_iklan', '<small class="text-danger pl-3">','</small>') ?>

			</div>

				<div class="form-group row">
				<div class="col-4">
					<label for="deskripsi">Deskripsi Iklan <span class="text-danger">*</span></label>
				</div>
				<div class="col-8">
					<textarea name="deskripsi" maxlength="200" value="<?php echo set_value('deskripsi') ?>"></textarea>
				</div>
				<?php echo form_error('deskripsi', '<small class="text-danger pl-3">','</small>') ?>

			</div>

			<div class="form-group row">
				<div class="col-4">
					<label for="nama_usaha">Perusahaan <span class="text-danger">*</span></label>
				</div>
				<div class="col-8">
					<input type="text" name="nama_usaha" class="form-control" value="<?php echo set_value('nama_usaha') ?>" placeholder="Masukan nama perusahaan">
				</div>
				<?php echo form_error('nama_usaha', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
					<label for="sejak">Berdiri Sejak</label>
				</div>
				<div class="col-8">
					<input type="date" name="sejak" class="form-control">
				</div>
				<?php echo form_error('sejak', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
					<label for="jumlah_gerai">Jumlah Gerai <span class="text-danger">*</span></label>
				</div>
				<div class="col-8">
					<input type="text" name="jumlah_gerai" class="form-control">
				</div>	
				<?php echo form_error('jumlah_gerai', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
				<label for="modal">Modal Awal <span class="text-danger">*</span></label>
				</div>
				<div class="col-8">
				<input type="text" name="modal" class="form-control">
				</div>		
				<?php echo form_error('modal', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
				<label for="fee">Outlet Fee</label>
				</div>
				<div class="col-8">
				<input type="text" name="fee" class="form-control">
				</div>	
				<?php echo form_error('fee', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
					<label for="royalty">Biaya Royalti</label>
				</div>
				<div class="col-8">
				<input type="text" name="royalty" class="form-control">
				</div>	
				<?php echo form_error('royalty', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
				<label for="advertising">Biaya Advertising</label>
				</div>
				<div class="col-8">
				<input type="text" name="advertising" class="form-control">
				</div>	
				<?php echo form_error('advertising', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="form-group row">
				<div class="col-4">
				<label for="gambar">Gambar</label>
				</div>
				<div class="col-8">
				<input type="file" name="berkas" class="form-control-file">	
				</div>	
				<?php echo form_error('berkas', '<small class="text-danger pl-3">','</small>') ?>
			</div>

			<div class="text-center" >
				<button type="submit" class="btn btn-primary form-control" >Pasang</button>
			</div>
			

		</form>
	<?php endif ?>
	
	</div>	
</div>	