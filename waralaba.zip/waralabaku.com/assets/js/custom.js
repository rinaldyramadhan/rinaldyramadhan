/* dd menu */
var dd = document.getElementsByClassName("dd-btn-user");
var i;

for (i= 0; i < dd.length; i++) {
	dd[i].addEventListener("click", function() {
		this.classList.toggle("aktif");
		var ddContent = this.nextElementSibling;
		if (ddContent.style.display === "block") {
			ddContent.style.display = "none";
		} else {
			ddContent.style.display = "block";
		}
	});
}

/* dd menu */
var dd = document.getElementsByClassName("dd-btn-iklan");
var i;

for (i= 0; i < dd.length; i++) {
	dd[i].addEventListener("click", function() {
		this.classList.toggle("aktif");
		var ddContent = this.nextElementSibling;
		if (ddContent.style.display === "block") {
			ddContent.style.display = "none";
		} else {
			ddContent.style.display = "block";
		}
	});
}