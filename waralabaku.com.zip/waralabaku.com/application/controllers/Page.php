<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	private $template = "layout/template";

	public function index()
	{
		$data['konten']		=		'home';
		$this->load->view($this->template,$data);
	}

	public function direktori_waralaba()
	{
		$data['konten']		=		'dir-waralaba';
		$this->load->view($this->template,$data);
	}
}
