<p class="text-index">
	<small>
		<a href="" title="">Featured Franchise</a> <br>
		Daftar usaha waralaba yang menjadi prioritas utama advertising WaralabaKu.com
	</small>		
</p>

<p class="text-index">
	<small>
		<a href="" title="">Popular Franchise</a> <br>
		Daftar usaha waralaba yang paling banyak dikunjungi oleh pengunjung WaralabaKu.com (hit rate tertinggi)
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Berdasarkan Kategori</a> <br>
		Daftar usaha waralaba berdasarkan kategori dan sub kategori industri atau bidang usaha.
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Berdasarkan Abjad</a> <br>
		Daftar usaha waralaba berdasarkan urutan alfabet dari nama merek dagangnya.
	</small>		
</p>	


<p class="text-index">
	<small>
		<a href="" title="">Advanced Search</a> <br>
		Klik untuk menggunakan fasilitas advanced search kami dalam mencari informasi tentang usaha waralaba yang spesifik.
	</small>		
</p>	


<hr>


