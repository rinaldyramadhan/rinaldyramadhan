 <header id="header" class="text-center">
               <p class="ml-2">Welcome</p>
              </header><!-- /header -->

              <div class="mt-2 mb-2 text-index">
                <small class="text-index">Selamat Datang di WaralabaKu.com
                    WaralabaKu.com merupakan portal yang bertujuan untuk membantu para calon franchisee (penerima waralaba) mendapatkan informasi mengenai bisnis franchise yang diinginkan sebelum memutuskan untuk memulai bisnis.
                    WaralabaKu.com tidak hanya menampilkan direktori Franchise (Waralaba) tapi juga Peluang Usaha, Peluang Bisnis, Lisensi, dan Keagenan.

                    Siap untuk mengembangkan bisnis Anda ke seluruh Nusantara? Klik di sini untuk memulainya!
                </small>
              </div>

             

              <div class="mt-2 mb-2 text-index">
                <h5><strong>Temukanlah Bisnis Franchise yang Anda Impikan!</strong></h5>
                <small class="text-index">Carilah bisnis franchise yang tersedia di direktori franchise kami dengan menggunakan fasilitas pencarian yang telah kami sediakan silakan klik disini !! 
                <br> <br>
                Pelajarilah informasi mengenai bisnis franchise yang meliputi informasi alamat dan kontak perusahaan, profil bisnis serta proposal franchise yang tersedia pada masing-masing franchisor (pemberi waralaba) dan temukan bisnis franchise mana yang paling sesuai bagi Anda.
                </small>
              </div>